package CuentaBancaria;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class MainBanco {

	public static void main(String[] args) 
	{
		String titular="", entidad="", oficina="", DC="", numCuenta="";
		boolean fin=false;
		CuentaBancaria p1 = new CuentaBancaria(titular, entidad, oficina, DC, numCuenta);
        String[] opciones= {"Ver n�mero de cuenta completo.",
				"Ver titular de la cuenta.",
				"Ver codigo de la entidad.",
				"Ver codigo de la oficina",
				"Ver el numero de la cuenta.",
				"Ver digitos de control de la cuenta.",
				"Realizar ingreso.",
				"Retirar efectivo.",
				"Consultar saldo.",
				"Salir."};
       p1.setTitular(JOptionPane.showInputDialog("Introduzca su nombre.(Min. 10 y max. 100 caracteres)"));
       CuentaBancaria.comprobarCCC(JOptionPane.showInputDialog("Introduzca su numero de cuenta: "));
       while(fin==false)
       {
	        int sel = JOptionPane.showOptionDialog(null,
					"Que operacion quieres realizar", 
					"Operacion a realizar", 
					JOptionPane.YES_NO_CANCEL_OPTION, 
					JOptionPane.INFORMATION_MESSAGE,
					null,
					opciones,
					null);
	        switch (sel)
			{
			case 0://Ver n�mero de la cuenta
				JOptionPane.showMessageDialog(null, p1.getNumCuenta());
			break;
			case 1://Ver titular de la cuenta
				
			break;
			case 2://Ver codigo de la entidad
				
			break;
			case 3://Ver el codigo de la oficina
				
			break;
			case 4://Ver el numero de la cuenta(solo el numero de cuenta.)
				
			break;
			case 5://Ver los digitos de control de la cuenta
				JOptionPane.showMessageDialog(null, p1.obtenerDigitosControl());
			break;
			case 6://Realizar ingreso
				p1.ingresar(Double.parseDouble(JOptionPane.showInputDialog("Cantidad a ingresar.")));
			break;
			case 7://Retirar efectivo
				p1.retirar(Double.parseDouble(JOptionPane.showInputDialog("Cantidad a retirar.")));
			break;
			case 8://Consultar saldo
				
			break;
			case 9://Salir
				JOptionPane.showMessageDialog(null, "Cerrando sesion.");
				fin=true;
			break;
			}
        
       }
		
	}

}
