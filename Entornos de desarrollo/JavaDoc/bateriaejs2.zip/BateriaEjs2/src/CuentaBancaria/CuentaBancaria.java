package CuentaBancaria;

public class CuentaBancaria 
{
	private String titular;
	private double saldo;
	private String entidad;
	private String oficina;
	private String numCuenta;
	public static int tamMax;
	public static int tamMin;
	
	public CuentaBancaria(String titular, String entidad, String oficina, String DC, String numCuenta)
	{
		this.titular=titular;
		this.entidad=entidad;
		this.oficina=oficina;
		this.tamMax=100;
		this.tamMin=10;
	}
	
	public CuentaBancaria(String titular, String CCC)
	{
		this.titular=titular;
		this.tamMax=100;
		this.tamMin=10;
	}
	
	public void ingresar(double cantidad)
	{
		
		if(cantidad>0 && cantidad<saldo)
		{
			saldo+=cantidad;
		}else 
			throw new IllegalArgumentException("La cantidad no puede ser negativa.");
	}
	
	public void retirar(double cantidad)
	{
		if(cantidad>0)
		{
			if(cantidad<saldo)
			{
				saldo-=cantidad;
			}else
				throw new IllegalArgumentException("La cantidad no puede ser mayor que el saldo de la cuenta.");
		}else 
			throw new IllegalArgumentException("La cantidad no puede ser negativa.");
	}
	
	public static boolean comprobarCCC(String CCC)
	{
		try
		{
//			if(entidad.length())
//			{
//				
//			}else
//				throw new Exception();
		}catch (Exception e) {
			// TODO: handle exception
		}
		return true;
	}
	
	public String obtenerDigitosControl()
	{
		entidad="1234";
		oficina="5678";
		numCuenta="1234567890";
		String digControl="";
		int part1=0, part2=0;
		String a= "00"+getEntidad()+getOficina();
		int[] pesos= {1,2,4,8,5,10,9,7,3,6};
		for (int i = 0; i < pesos.length; i++) {
			char eo = a.charAt(i);
			char nc = getNumCuenta().charAt(i);
			part1=part1+(pesos[i]*Character.getNumericValue(eo));
			part2=part2+(pesos[i]*Character.getNumericValue(nc));
		}
		part1=11-(part1%11);
		part2=11-(part2%11);
		if(part1==10){
			part1=1;
		} else if(part1==11){
			part1=0;
		} else if(part2==10) {
			part2=1;
		} else if(part2==11) {
			part2=0;
		}
		digControl=part1+""+part2;
		return digControl;
	}
	
	public String toString()
	{
		String datos;
		datos="Nombre del titular: "+titular+
				"\nCodigo Cuenta Cliente: "+getEntidad()+getOficina()+
				obtenerDigitosControl()+getNumCuenta()+
				"\nSaldo de la cuenta: "+saldo;
		return datos;
		
	}
	
	public String getTitular() 
	{
		return titular;
	}

	public void setTitular(String titular) 
	{
		this.titular = titular;
	}

	public double getSaldo() 
	{
		return saldo;
	}

	public String getEntidad() 
	{
		return entidad;
	}
	
	public String getOficina() 
	{
		return oficina;
	}

	public String getNumCuenta() 
	{
		return numCuenta;
	}
	
	
	
	
}
