package Biblioteca;

import javax.swing.JOptionPane;

public class Libro 
{
	
	private String titulo;
	private String autor;
	private String isbn;
	
	public Libro(String titulo, String autor, String isbn) 
	{
		this.autor=autor;
		this.isbn=isbn;
		this.titulo=titulo;
	}
	
	public void consulta_isbn()
	{
		getIsbn();
	}
	
	public void cambia_isbn(int tip)
	{
		
		try
		{
			if(tip==10)
			{
				setIsbn(JOptionPane.showInputDialog("Introduzca el ISBN: "));
				compruebaIsbn10();
				JOptionPane.showMessageDialog(null, "Autor modificado correctamente.");
			} else {
				compruebaIsbn13();
				JOptionPane.showMessageDialog(null, "Autor modificado correctamente.");
			}
			
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ISBN no valido.");
			cambia_isbn(tip);
		}
	}
	
	public void consulta_autor()
	{
		JOptionPane.showMessageDialog(null, getAutor());
	}
	
	public void cambia_autor()
	{
		setAutor(JOptionPane.showInputDialog("Modificar autor."));
		JOptionPane.showMessageDialog(null, "Autor modificado correctamente.");
	}
	
	public void consulta_titulo()
	{
		JOptionPane.showMessageDialog(null, getTitulo());
	}
	
	public void cambia_titulo()
	{
		setTitulo(JOptionPane.showInputDialog("Modificar titulo."));
		JOptionPane.showMessageDialog(null, "Titulo modificado correctamente.");
	}
	
	private boolean compruebaIsbn10()
	{
		int suma=0, cont=1;
		for (int i = 0; i < this.isbn.length(); i++) 
		{
			char aux = this.isbn.charAt(i);
			if(aux=='-')
			{
			
			} else if (aux=='x' || aux=='X'){
				suma+=10;
			} else {
				suma=suma+(aux*cont++);
			}
		}
		if(suma%11==0)
		{
			return true;
		}else 
			throw new IllegalArgumentException("isbn no v�lido");
	}
	
	private boolean compruebaIsbn13()
	{
		int suma=0;
		char aux='1';
		boolean guion=false;
		for (int j = 0; j < 4; j++) {
			if(this.isbn.charAt(3)=='-')
			{
				guion=true;
			}
		}
		for (int i = 0; i < this.isbn.length(); i++) 
		{
			aux = this.isbn.charAt(i);
			int cont=i;
			if(aux=='-' || (cont)==this.isbn.length())
			{
				cont--;
			} else if (guion==true){
				if(aux=='-' || (cont)==this.isbn.length())
				{
					cont--;
				} else if((cont)%2==0)
				{
					suma=suma+(Character.getNumericValue(aux)*3);
				}else {
					suma=suma+(Character.getNumericValue(aux)*1);
				}
			} else if(guion==false){
				if(aux=='-' || (i+1)==this.isbn.length())
				{
					
				} else if((i+1)%2==0)
				{
					suma=suma+(Character.getNumericValue(aux)*3);
				}else {
					suma=suma+(Character.getNumericValue(aux)*1);
				}
			}
		}
		suma=suma%10;
		if(Character.getNumericValue(aux)==(10-suma))
		{
			return true;
		} else
			throw new IllegalArgumentException("isbn no v�lido");
		
	}
	
	public String getTitulo() 
	{
		return titulo;
	}
	
	public void setTitulo(String titulo) 
	{
		this.titulo = titulo;
	}
	
	public String getAutor() 
	{
		return autor;
	}
	
	public void setAutor(String autor) 
	{
		this.autor = autor;
	}
	
	public String getIsbn() 
	{
		return isbn;
	}
	
	public void setIsbn(String isbn)
	{
		this.isbn = isbn;
	}
	
	
	
	
	
}
