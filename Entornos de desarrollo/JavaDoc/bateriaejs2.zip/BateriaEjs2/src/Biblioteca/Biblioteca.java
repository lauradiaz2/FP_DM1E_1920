package Biblioteca;

import javax.swing.JOptionPane;

public class Biblioteca {

	public static void main(String[] args) 
	{
		String titulo="", autor="", isbn="";
		Libro libro1 = new Libro(titulo, autor, isbn);
		int tipo;
		String[] acciones = new String[2];
			acciones[0]="Consultar";
			acciones[1]="Cambiar";
		
		String [] tipo2 = new String[3];
			tipo2[0]="Titulo";
			tipo2[1]="Autor";
			tipo2[2]="ISBN";
			
		String[] tipoIsbn = new String[2];
			tipoIsbn[0]="ISBN-10";
			tipoIsbn[1]="ISBN-13";
			int a = JOptionPane.showOptionDialog(null,
					"Accion a realizar: ", 
					"Biblioteca", 
					JOptionPane.YES_NO_CANCEL_OPTION, 
					JOptionPane.INFORMATION_MESSAGE,
					null,
					acciones,
					null);
			
		
			switch(a)
			{
				case 0: //Consultar
					
					int b = JOptionPane.showOptionDialog(null,
							"�Que quieres consultar?", 
							"Biblioteca", 
							JOptionPane.YES_NO_CANCEL_OPTION, 
							JOptionPane.INFORMATION_MESSAGE,
							null,
							tipo2,
							null);
					switch(b)
					{
						case 0: //Titulo
							JOptionPane.showMessageDialog(null, libro1.getTitulo());
						break;
						case 1: //Autor
							JOptionPane.showMessageDialog(null, libro1.getAutor());
						break;
						case 2: //Isbn
							JOptionPane.showMessageDialog(null, libro1.getIsbn());
						break;
					}
				break;
				case 1: //Cambiar
					int c = JOptionPane.showOptionDialog(null,
							"�Que quieres cambiar?", 
							"Biblioteca", 
							JOptionPane.YES_NO_CANCEL_OPTION, 
							JOptionPane.INFORMATION_MESSAGE,
							null,
							tipo2,
							null);
					switch(c)
					{
						case 0: //Titulo
							libro1.cambia_titulo();
						break;
						
						case 1: //Autor
							
							libro1.cambia_autor();
							
						break;
						
						case 2: //Isbn
							tipo = JOptionPane.showOptionDialog(null,
									"Tipo de ISBN: ", 
									"Biblioteca", 
									JOptionPane.YES_NO_CANCEL_OPTION, 
									JOptionPane.INFORMATION_MESSAGE,
									null,
									tipoIsbn,
									null);
							switch(tipo)
							{
								case 0: //ISBN-10
									int tip=10;
									
									libro1.cambia_isbn(tip);
								break;
								
								case 1: //ISBN-13
									tip=13;
									libro1.setIsbn(JOptionPane.showInputDialog("Introduzca el ISBN: "));
									libro1.cambia_isbn(tip);
								break;
							}
							
						break;
					}
				break;
		}
	}

}
