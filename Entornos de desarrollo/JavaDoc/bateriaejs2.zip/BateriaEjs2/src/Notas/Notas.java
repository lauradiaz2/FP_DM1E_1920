package Notas;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Notas 
{
	private double nota;
	Notas()
	{
		this.nota=0;
	}
	
	Scanner input = new Scanner(System.in);
	
	public void comprobarNotas()
	{
		try
		{
			cNotas();
			
		}catch(NotasValidas e)
		{
			JOptionPane.showMessageDialog(null, e.toString());
			comprobarNotas();
		}
	}
	
	private void cNotas() throws NotasValidas
	{
		int suspensos=0,aprobados=0;
		double media=0;
		String notax;
			while(this.nota>=0)
			{
				notax=JOptionPane.showInputDialog("Introduzca notas: ");
				for (int i = 0; i < notax.length(); i++) 
				{
					char a =notax.charAt(i);
					if((i==0 && a=='-'))
					{
						
					}else if(!Character.isDigit(a)) 
						throw new NotasValidas();
				}
				this.nota=Double.parseDouble(notax);
				if(this.nota<=10 )
				{
					if(nota>=5)
					{
						aprobados++;
						media+=this.nota;
					}else if(this.nota<5 && nota>=0){
						suspensos++;
						media+=this.nota;
					}
				} else {
					JOptionPane.showMessageDialog(null, ("Vuelva a introducir la nota."));
					}
			}
			media=media/(aprobados+suspensos);
			JOptionPane.showMessageDialog(null, "Aprobados: "+aprobados+
					"\nSuspensos: "+suspensos+
					"\nMedia: "+media);
		
			input.close();
	}
	
}
