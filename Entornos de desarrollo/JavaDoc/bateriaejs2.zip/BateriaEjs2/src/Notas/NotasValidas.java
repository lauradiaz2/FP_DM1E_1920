package Notas;

public class NotasValidas extends Exception
{
	NotasValidas()
	{
		super("Nota no valido.");
	}
	
}
