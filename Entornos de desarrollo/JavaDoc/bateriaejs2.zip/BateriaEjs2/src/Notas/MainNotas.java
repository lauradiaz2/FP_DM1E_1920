package Notas;

public class MainNotas 
{
	public static void main(String[] args) 
	{
		Notas n = new Notas();
		n.comprobarNotas();
	}
}
