package Calculadora;

import javax.swing.JOptionPane;

public class Division extends Operaciones {

	public Division(int cod, double numero1, double numero2, double resultado) 
	{
		super(cod, numero1, numero2, resultado);
		// TODO Auto-generated constructor stub
	}

	public void div() throws Excepciones
	{
		if(getOp2()!=0)
		{
			setResult(getOp1()/getOp2());
		} else throw new Excepciones();
	}
	
	public void comprobar() throws Excepciones
	{
		try 
		{
			div();
		}
		catch (Excepciones e) {
			JOptionPane.showMessageDialog(null, "ERROR. El divisor debe ser distinto de 0.");
			intr.pedirOp2();
			setOp2(intr.getOp2());
			comprobar();
		}
	}
}
