package Calculadora;

public class Potencia extends Operaciones {

	public Potencia(int cod, double numero1, double numero2, double resultado) 
	{
		super(cod, numero1, numero2, resultado);
		// TODO Auto-generated constructor stub
	}

	public void potencia()
	{
		setResult(Math.pow(getOp1(), getOp2()));//Op1 --> base
												//Op2 --> exponente
	}
}
