package Calculadora;

import javax.swing.JOptionPane;

public class Inputs 
{
	private String tipo[];
	private String opcionesB[];
	private String opcionesC[];
	private double op1;
	private double op2;
	private int cod; //Codigo op basicas
	private int compl; //Codigo op complejas
	
	Inputs()
	{
		this.op1=0;
		this.op2=0;
		this.cod=0;
		this.compl=0;
		opcionesB= new String[5];
			opcionesB[0]="SUMA";
			opcionesB[1]="RESTA";
			opcionesB[2]="MULTIPLICACION";
			opcionesB[3]="DIVISION";
			opcionesB[4]="REINICIAR";	
		opcionesC = new String[3];
			opcionesC[0] = "RAIZ";
			opcionesC[1] ="POTENCIA";
			opcionesC[2] ="REINICIAR";
		tipo=new String[3];
			tipo[0]="Basicas";
			tipo[1]="Complejas";
			tipo[2]="Salir";
	}
	public void tipoOp()
	{
		compl = JOptionPane.showOptionDialog(null,
				"Que operacion quieres realizar", 
				"Operacion a realizar", 
				JOptionPane.YES_NO_CANCEL_OPTION, 
				JOptionPane.INFORMATION_MESSAGE,
				null,
				tipo,
				null);
	}
	
	public void pedirCod2()
	{
		cod = JOptionPane.showOptionDialog(null,
				"Que operacion quieres realizar", 
				"Operacion a realizar", 
				JOptionPane.YES_NO_CANCEL_OPTION, 
				JOptionPane.INFORMATION_MESSAGE,
				null,
				opcionesC,
				null);
		
	}
	
	public void pedirCod()
	{
		cod = JOptionPane.showOptionDialog(null,
				"Que operacion quieres realizar", 
				"Operacion a realizar", 
				JOptionPane.YES_NO_CANCEL_OPTION, 
				JOptionPane.INFORMATION_MESSAGE,
				null,
				opcionesB,
				null);
		
	}
	
	public void pedirOp1() throws Excepciones
	{
		op1=Double.parseDouble(JOptionPane.showInputDialog("Numero 1:"));
	}
	
	public void pedirOp2() throws Excepciones
	{
		op2=Double.parseDouble(JOptionPane.showInputDialog("Numero 2:"));
	}
	
	public String[] getTipo() {
		return tipo;
	}
	
	public void setTipo(String[] tipo) {
		this.tipo = tipo;
	}
	
	public String[] getOpciones() {
		return opcionesB;
	}
	
	public void setOpciones(String[] opciones) {
		this.opcionesB = opciones;
	}
	
	public double getOp1() {
		return op1;
	}
	
	public void setOp1(double op1) {
		this.op1 = op1;
	}
	
	public double getOp2() {
		return op2;
	}
	
	public void setOp2(double op2) {
		this.op2 = op2;
	}
	
	public int getCod() {
		return cod;
	}
	
	public void setCod(int cod) {
		this.cod = cod;
	}
	
	public int getCompl() {
		return compl;
	}
	
	public void setCompl(int compl) {
		this.compl = compl;
	}
	public String[] getOpcionesB() {
		return opcionesB;
	}
	public void setOpcionesB(String[] opcionesB) {
		this.opcionesB = opcionesB;
	}
	public String[] getOpcionesC() {
		return opcionesC;
	}
	public void setOpcionesC(String[] opcionesC) {
		this.opcionesC = opcionesC;
	}
	
	
}
