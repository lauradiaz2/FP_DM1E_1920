package Calculadora;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) throws Excepciones 
	{
		// TODO Auto-generated method stub
		double op1=0,op2=0,result=0;
		int cod=0,cont=0;
		boolean fin=true;
		Suma s = new Suma(cod,op1,op2,result);
		Resta r = new Resta(cod,op1,op2,result);
		Division d = new Division(cod,op1,op2,result);
		Multiplicacion m = new Multiplicacion(cod,op1,op2,result);
		Potencia p = new Potencia(cod,op1,op2,result);
		RaizCuadrada ra = new RaizCuadrada(cod,op1,op2,result);
		Inputs introval = new Inputs();
		while(fin==true)
		{
			introval.tipoOp();
			if(cont==0)
			{
				introval.pedirOp1();
			}
			switch (introval.getCompl())
			{
			case 0://Basicas
				introval.pedirCod();
				if(introval.getCod()!=4)
				{
					introval.pedirOp2();
				}
				switch(introval.getCod())
				{
				case 0: //Suma
					s.setOp1(introval.getOp1());
					s.setCod(introval.getCod());
					s.setOp2(introval.getOp2());
					s.sim();
					s.sum();
					JOptionPane.showMessageDialog(null, s.mostrarOperB());
					introval.setOp1(s.getResult());
				break;
				case 1: //Resta
					r.setOp1(introval.getOp1());
					r.setCod(introval.getCod());
					r.setOp2(introval.getOp2());
					r.sim();
					r.rest();
					JOptionPane.showMessageDialog(null, r.mostrarOperB());
					introval.setOp1(r.getResult());
				break;
				case 2: //Multiplicacion
					m.setOp1(introval.getOp1());
					m.setCod(introval.getCod());
					m.setOp2(introval.getOp2());
					m.sim();
					m.mult();
					JOptionPane.showMessageDialog(null, m.mostrarOperB());
					introval.setOp1(m.getResult());
				break;
				case 3: //Division
						d.setOp1(introval.getOp1());
						d.setCod(introval.getCod());
						d.setOp2(introval.getOp2());
						d.sim();
						d.comprobar();
						JOptionPane.showMessageDialog(null, d.mostrarOperB());
						introval.setOp1(d.getResult());
				break;
				case 4: //Reiniciar
					JOptionPane.showMessageDialog(null,"Reiniciando valores.");
					cont=0;
				break;
				}
				
			break;
			case 1://Complejas
				introval.pedirCod2();
				if(introval.getCod()!=0)
				{
					introval.pedirOp2();
				}
				switch(introval.getCod())
				{
				case 0://Raiz
					ra.setOp1(introval.getOp1());
					ra.setOp2(introval.getOp2());
					ra.setCod(introval.getCod());
					ra.compl();
					ra.raiz();
					JOptionPane.showMessageDialog(null, ra.mostrarOperC());
					introval.setOp1(ra.getResult());
				break;
				case 1://Potencia
					p.setOp1(introval.getOp1());
					p.setOp2(introval.getOp2());
					p.setCod(introval.getCod());
					p.compl();
					p.potencia();
					JOptionPane.showMessageDialog(null, p.mostrarOperC());
					introval.setOp1(p.getResult());
				break;
				case 2://Reiniciar
					JOptionPane.showMessageDialog(null,"Reiniciando valores.");
					cont=0;
				break;
				}
			
			break;
			case 2://Salir
				fin=false;
				JOptionPane.showMessageDialog(null,"FIN");
			break;
			}
			if(introval.getCod()!=4 && introval.getCompl()!=2)
			{
				int opcionFin = JOptionPane.showConfirmDialog(null, "�Quieres seguir operando?", "Calculadora", JOptionPane.YES_NO_OPTION);
				if(opcionFin == JOptionPane.YES_OPTION)
				{
					fin=true;
					cont++;
				}else {
					fin=false;
					JOptionPane.showMessageDialog(null,"FIN");
				}
			}
				
		}
		
	}

}
