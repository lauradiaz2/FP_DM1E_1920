package Calculadora;

public class Excepciones extends Exception
{
	Excepciones()
	{
		super("");
	}
}
