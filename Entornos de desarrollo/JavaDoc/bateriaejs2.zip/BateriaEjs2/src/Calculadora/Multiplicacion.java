package Calculadora;

public class Multiplicacion extends Operaciones {

	public Multiplicacion(int cod, double numero1, double numero2, double resultado) 
	{
		super(cod, numero1, numero2, resultado);
		// TODO Auto-generated constructor stub
	}

	public void mult()
	{
		
		setResult(getOp1()*getOp2());
	}
}
