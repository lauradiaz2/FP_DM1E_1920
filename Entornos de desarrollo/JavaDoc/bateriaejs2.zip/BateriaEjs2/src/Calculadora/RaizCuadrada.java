package Calculadora;

public class RaizCuadrada extends Operaciones {

	public RaizCuadrada(int cod, double numero1, double numero2, double resultado) 
	{
		super(cod, numero1, numero2, resultado);
		// TODO Auto-generated constructor stub
	}

	public void raiz()
	{
		setResult(Math.sqrt(getOp1()));
	}
}
