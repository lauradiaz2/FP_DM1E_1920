package primerpaquete;

public class primeraclase {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.out.println("Hola clase :)");
		System.out.println("Vamos a depurar nuestro codigo por primera vez");
		System.out.println("Para poder depurar vamos a necesitar puntos de ruptura");
		System.out.println("¿Cómo los añadimos?");
		System.out.println("Nos vamos al numero de linea que queremos añadir");
		System.out.println("Hacemos click derecho en la linea y le daremos a toggle breakpoint");
		int a;
		a = 0;
		if (a>0)
			System.out.println("Numero positivo, numero bonito");
		else
			System.out.println("Numero negativo, numero feo");
		
		for(int i = 0; i<=10;i++) 
		{
			System.out.println(a*i);		
		}
		
		do
		{
			a--;
			System.out.print(a);
		}while(a > 0);
	}

}
