package primeraPaquete;

public class Avion 
{
	String modelo;
	int ruedas;
	int asientos;
	int ventanas;
	String motor;
	
	public String getModelo()
	{
		return modelo;	
	}
	
	public void setModelo(String _modelo)
	{
		this.modelo = _modelo;
	}
	
	public int getRuedas()
	{
		return ruedas;
	}
	
	public void setRuedas(int _ruedas)
	{
		this.ruedas = _ruedas;
	}
	
	public int getAsientos()
	{
		return asientos;
	}
	
	public void setAsientos(int _asientos)
	{
		this.asientos = _asientos;
	}
	
	public int getVentanas()
	{
		return ventanas;
	}
	
	public void setVentanas(int _ventanas)
	{
		this.ventanas = _ventanas;
	}
	
	public String getMotor()
	{
		return motor;
	}
	
	public void setMotor(String _motor)
	{
		this.motor = _motor;
	}

	void mostrarAvion()
	{
		System.out.println("Mostramos la información del avion:");
		System.out.println("Modelo: "+getModelo());
		System.out.println("Numero de ruedas: "+getRuedas());
		System.out.println("Numero de asientos:"+getAsientos());
		System.out.println("Numero de ventanas: "+getVentanas());
		System.out.println("Modelo del motor: "+getMotor());
	}
	
}
