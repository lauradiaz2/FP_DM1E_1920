package ejercicios;

import java.util.Scanner;

//import java.util.Scanner;

public class Main {
	
	
	
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		EjerciciosPSEINT ej1 = new EjerciciosPSEINT();
		System.out.println("Bateria, MPF o  Utils");
		String tipo = input.nextLine();
		switch (tipo)
		{
		case "bateria":
			System.out.println("Numero de ejercicio?");
			int ejercicios = input.nextInt();
			switch (ejercicios)
			{
			case 1:
				ej1.MostrarEjer1(input);
			break;
			case 2:
				ej1.MostrarEjer2(input);
			break;
			case 3:
				ej1.MostrarEjer3(input);
			break;
			case 4:
				ej1.MostrarEjer4(input);
			break;
			case 5:
				ej1.MostrarEjer5(input);
			break;
			case 6:
				ej1.MostrarEjer6(input);
			break;
			case 7:
				ej1.MostrarEjer7(input);
			break;
			case 8:
				ej1.MostrarEjer8(input);
			break;
			case 9:
				ej1.MostrarEjer9(input);
			break;
			case 10:
				ej1.MostrarEjer10(input);
			break;
			case 11:
				ej1.MostrarEjer11(input);
			break;
			case 12:
				ej1.MostrarEjer12(input);
			break;
			case 13:
				ej1.MostrarEjer13(input);
			break;
			case 14:
				ej1.MostrarEjer14(input);
			break;
			case 15:
				ej1.MostrarEjer15(input);
			break;
			case 16:
				ej1.MostrarEjer16(input);
			break;
			case 17:
				ej1.MostrarEjer17(input);
			break;
			case 18:
				ej1.MostrarEjer18(input);
			break;
			case 19:
				ej1.MostrarEjer19(input);
			break;
			case 20:
				ej1.MostrarEjer20(input);
			break;
			case 21:
				ej1.MostrarEjer21(input);
			break;
			case 22:
				ej1.MostrarEjer22(input);
			break;
			case 23:
				ej1.MostrarEjer23(input);
			break;
			case 24:
				ej1.MostrarEjer24(input);
			break;
			case 25:
				ej1.MostrarEjer25(input);
			break;
			case 26:
				ej1.MostrarEjer26(input);
			break;
			case 27:
				ej1.MostrarEjer27(input);
			break;
			case 28:
				ej1.MostrarEjer28(input);
			break;
			case 29:
				ej1.MostrarEjer29(input);
			break;
			case 30:
				ej1.MostrarEjer30(input);
			break;
			case 31:
				ej1.MostrarEjer31(input);
			break;
			case 32:
				ej1.MostrarEjer32(input);
			break;
			}
		break;
		case "MPF":
			System.out.println("Numero ejercicio?");
			int ejercicio = input.nextInt();
			switch (ejercicio)
			{
			case 1:
			{
				double a,b;
				System.out.println("Dime 2 numeros");
				a = input.nextDouble();
				b = input.nextDouble();
				//EjercicioMPF1
				System.out.println("La suma de "+a+" "+b+ "es = "+ej1.suma1(a,b));
			}
			break;
			case 2:
			{
				//EjercicioMPF2
				int c;
				System.out.println("Dime 1 numero");
				c = input.nextInt();
				ej1.numPrimo(c);
			}
			break;
			case 3:
			{	//EjercicioMPF3
				
				 System.out.println("Dime un número (FACTORIAL)"); int num1 = input.nextInt();
				 System.out.println("El factorial de "+num1+" es "+ej1.factoriales(num1));
			}	 
			break;
			case 4:
			{	//EjercicioMPF4
				  int x; 
				  int b; 
				  System.out.println("Dime un número"); 
				  x = input.nextInt();
				  System.out.println("Dime el numero que quieres mostrar"); 
				  b = input.nextInt(); 
				  ej1.posicion(x,b);
			}
			break;
			case 5:
			{
				//EjercicioMPF5
				  int num6; 
				  System.out.println("Dime un número"); 
				  num6 = input.nextInt();
				  ej1.vuelta(num6);
			}
			break;
			case 6:
			{
				 //EjercicioMPF6
				  int n; 
				  System.out.println("Dime un número (pasar a Binario)"); 
				  n = input.nextInt(); 
				  ej1.bin_dec(n);
			}
			break;
			case 7:
			{
				//EjercicioMPF7
					int nu;
					System.out.println("Dime un número (pasar a OCTAL)");
					nu = input.nextInt();
					ej1.oct_dec(nu);
			}
			break;
			case 8:
			{
				//EjercicioMPF8
					int num;
					System.out.println("Dime un número (pasar a Hexadecimal)");
					num = input.nextInt();
					ej1.hex_dec(num);
			}
			break;
			case 9:
				//EjercicioMPF9
					int nume;
					System.out.println("Dime un número (primos anteriores a éste)");
					nume = input.nextInt();
					ej1.primosAnteriores(nume);
			break;
			case 10:
				//EjercicioMPF10
				int numer;
				System.out.println("Dime un número (factoriales de 0 a este numero)");
				numer = input.nextInt();
				ej1.factoriales2(numer);
			break;
			case 11:
				//EjercicioMPF11
				
				String numeri;
				String numerit;
				String numerito;
				System.out.println("Dime un número");
				numeri = input.nextLine();
				System.out.println("Operacion a realizar");
				numerit = input.nextLine();
				System.out.println("Dime un número");
				numerito = input.nextLine();
				ej1.calc(numeri,numerit,numerito);
			break;
			case 12:
				//EjercicioMPF12
				
				String conv;
				String opcion;
				System.out.println("Dime un numero(hex,oct,bin)");
				conv = input.nextLine();
				System.out.println("¿A que lo quieres convertir? Binario, octal o hexadecimal");
				opcion = input.nextLine();
				ej1.conversion(conv,opcion);
			break;
				
			}
			
			
		break;
		case "utils":
		{
			System.out.println("numero de ejercicio?");
			int ejercicio1 = input.nextInt();
			switch (ejercicio1)
			{
			case 1:
			{
				String cad;
				String letra;
				System.out.println("Escribe una cadena");
				cad = input.next();
				System.out.println("Qué letra quieres saber que se repite");
				letra = input.next();
				ej1.cadena(cad,letra);
			}
			break;
			case 2:
			{
				String cadenita; 
				System.out.println("Escribe una cadena"); 
			  	cadenita = input.next(); 
			  	ej1.letnumesp(cadenita);
			}
			break;
			case 3:
			{
				String cade;
				System.out.println("Escribe una cadena(Cadena al revés)");
				cade = input.next();
				ej1.invert(cade);
			}
			break;
			case 4:
			{
				String base;
				String altura;
				System.out.println("Dime la base de la piramide");
				base = input.nextLine();
				System.out.println("Dime la altura de la piramide");
				altura = input.next();
				ej1.piramide(base,altura);
			}
			break;
			case 5:
			{
				String num;
				System.out.println("Dime un numero del 1 al 100");
				num=input.next/*Line*/();
				ej1.randomnum(num, input);
			}
			break;
			case 6:
			{
				String cad1;
				String cad2;
				System.out.println("Escribe 2 cadenas");
				cad1 = input.next();
				cad2 = input.next();
				ej1.mayuscad(cad1,cad2);
			}
			break;
			case 7:
			
				String cad1;
				System.out.println("Dime una cadena");
				cad1 = input.next();
				ej1.espejo(cad1);
			
			break;
			case 8:
				double x=90;
				ej1.coseno(x);
			break;
			default:
				System.out.println("No existe ese ejercicio");
			break;
			}
		}
		break;
		
		}
			input.close();
	}
	
	
	}