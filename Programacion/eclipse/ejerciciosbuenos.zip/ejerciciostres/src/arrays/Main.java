package arrays;

import java.util.Scanner;


public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		ejerciciosArrays ejercicios=new ejerciciosArrays();
		System.out.println("Arrays");
		String tipo = input.nextLine();
		switch (tipo)
		{
			case "A":
				ejerciciosArrays.arrayA();
			break;
			case "B":
				ejerciciosArrays.arrayB();
			break;
			case "C":
				ejerciciosArrays.arrayC();
			break;
			case "2":
				ejerciciosArrays.arrayAscendente();
			break;
			case "3":
				ejerciciosArrays.arrayDescendente();
			break;
			case "4":
				ejerciciosArrays.arrayPar();
			break;
			case "5":
				ejerciciosArrays.arrayImpar();
			break;
			case "6":
				ejerciciosArrays.arrayPrimo();
			break;
			case "7":
				ejerciciosArrays.arrayRandom();
			break;
			case "8":
				ejerciciosArrays.arraySum();
			break;
			case "9":
				ejerciciosArrays.arrayCircular();
			break;
			case "10":
				ejerciciosArrays.arrayPares2();
			break;
			case "11":
				ejerciciosArrays.arrayOperaciones(input);
			break;
			case "12":
				ejerciciosArrays.arrayOrdenAsc(input);
			break;
			case "13":
				ejerciciosArrays.arrayDoble(input);
			break;
			case "14":
				ejerciciosArrays.arrayDuplicar(input);
			break;
			case "15":
				ejerciciosArrays.arrayDupOrden(input);
			break;
			case "16":
				ejerciciosArrays.arrayParesSuma();
			break;
			case "17":
				ejerciciosArrays.arrayMedia(input);
			break;
			case "18":
				ejerciciosArrays.arrayOrdenados2(input);
			break;
			case "19":
				ejerciciosArrays.arrayPositivos(input);
			break;
			case "21":
				System.out.println(ejercicios.arrayBuscar(input));
			break;
			case "22":
				ejerciciosArrays.arrayPositivos(input);
			break;
			case "23":
				ejerciciosArrays.arrayPositivos(input);
			break;
			default:
				System.out.println("Ese ejercicio no existe.");
			break;
		}
		input.close();
	}

}
