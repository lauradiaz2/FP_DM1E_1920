package arrays;

import java.util.Random;

import java.util.Scanner;

public class ejerciciosArrays 
{
	
	
	//Ejercicio 1.A
	
	public static void arrayA()
	{
		double[] A= new double[3];
		double x=0;
		for (int i=0; i<A.length; i++)
		{
		A[i] = i*3;
		x = A[0]+A[1]+A[2];
		}
		System.out.println("A[0]="+A[0]+"\nA[1]="+A[1]+"\nA[2]="+A[2]+"\nx="+x);
	}
	
	//Ejercicio 1.B
	
	public static void arrayB()
	{
		int[] B = new int[5];
		for (int i=0; i<B.length; i++)
		{
		B[4]=1;
		B[B[4]]=2;
		B[B[B[4]]]=0;
		B[B[B[B[4]]]]=3;
		B[B[B[B[B[4]]]]]=4;
		System.out.println("B["+i+"]="+B[i]);
		}
	}
	
	//Ejercicio 1.C
	
	public static void arrayC()
	{
		int[] C= new int[4];
		int y;
		for (int i=C.length-1; i>=0; i--)
		{
			C[i] = i/2;
			y = C[0]+C[1]+C[2]+C[3];
			System.out.println("El valor de y= "+y+" en C["+i+"]= "+C[i]);
		}
	}
	
	//Ejercicio 2
	
	public static void arrayAscendente()
	{
		int[] numer= new int [100];
		
		for (int i=0; i<numer.length; i++)
		{
			numer[i]=i+1;
			System.out.println(numer[i]);
		}
	}
	
	//Ejercicio 3
	
	public static void arrayDescendente()
	{
		int[] numer= new int [100];
		
		for (int i=numer.length-1; i>=0; i--)
		{
			numer[i]=i+1;
			System.out.println(numer[i]);
		}
	}
	
	//Ejercicio 4
	
	public static void arrayPar()
	{
		int[] par= new int [100];
		for (int i=0; i<par.length; i++)
		{
			par[i]=i+1;
			if (par[i]%2==0)
			{
				System.out.println(par[i]);
			}
		}
	}
	
	//Ejercicio 5
	
	public static void arrayImpar()
	{
		int[] impar= new int [100];
		for (int i=0; i<impar.length; i++)
		{
			impar[i]=i+1;
			if (impar[i]%2!=0)
			{
				System.out.println(impar[i]);
			}
		}
	}
	
	//Ejercicio 6
	
	public static void arrayPrimo()
	{
		int[] primo= new int [100];
		
		for (int i=0; i<primo.length; i++)
		{
			int x=1;
			int cont=0;
			primo[i]=i+1;
			
			while(x<=primo[i])
			{
				if(primo[i]%x==0)
				{
					cont+=1;
					x++;
				}
				else
				{
					x++;
				}
			}
			if (cont==2)
			{
				System.out.println(primo[i]);
			}
		}
	}
	
	//Ejercicio 7
	
	public static void arrayRandom()
	{
		int[] random= new int [200];
		int maxRand=0,minRand=1000;
		for (int i=0; i<random.length; i++)
		{
			Random n = new Random();
			int n1 = n.nextInt(1000);
			random[i]= n1;
			System.out.println(random[i]);
			if(random[i]>maxRand)
			{
				maxRand=random[i];
			}
			else
			{
				if(random[i]<minRand)
				{
					minRand=random[i];
				}
			}
		}
		System.out.println("El numero más grande es "+maxRand+" y el más pequeño es "+minRand);
	}
	
	//Ejercicio 8
	
	public static void arraySum()
	{
		int[] sumax = new int [10];
		int sumab=0;
		for (int i=0; i < sumax.length; i++)
		{
			Random n = new Random();
			int n1 = n.nextInt(500);
			sumax[i]= n1;
			sumab += sumax[i]; 
			System.out.println(sumax[i]);
		}
		System.out.println("La suma de todos los numeros es "+sumab);
	}
	
	//Ejercicio 9
	
	public static void arrayCircular()
	{
		int[] circular = new int [10];
		int n=1;
		for (int i=0; i < circular.length; i++)
		{
			circular[i]=n++;
			System.out.println(circular[i]);
			if(i==circular.length-1)
			{
				i=0;
				n=1;
			}	
		}
	}
	
	//Ejercicio 10
	
	public static void arrayPares2()
	{
		int[] par = new int [200];
		for (int i=0; i < par.length; i++)
		{
			Random n = new Random();
			int n1 = n.nextInt(200);
			par[i]=n1;
			System.out.println(par[i]);
			if(par[i]%2==0)
			{
				System.out.println("Este es el primer numero par "+par[i]);
				i=par.length;
			}
		}		
	}
	
	//Ejercicio 11
	
	public static void arrayOperaciones(Scanner input)
	{
		int[] op = new int [10];
		int n=1;
		double sumas=0,resta=0,mult=1,divis=0;
		int x;
		for (int i=0; i < op.length; i++)
		{
			System.out.println(n+++". Dime un numero");
			x = input.nextInt();
			op[i]=x;
			sumas+=(double)op[i];
			resta=(double)resta - op[i];
			mult=(double)mult * op[i];
			divis =(double)divis/op[i];
		}
		System.out.println("La suma de los 10 numeros es "+sumas+"\nLa resta de los 10 números es "+resta+
				"\nLa multiplicacion de los 10 números es "+mult+"\nLa division de los 10 números es "+divis);
	}
	
	//Ejercicio 12
	
	public static void arrayOrdenAsc(Scanner input)
	{
		int[] op = new int [10];
		int n=1;
		int x;
		int aux;
		for (int i=0; i < op.length; i++)
		{
			System.out.println(n+++". Dime un numero");
			x = input.nextInt();
			op[i]=x;
		}
		for (int i=0; i < op.length; i++)
		{
			for (int j= i+1; j < op.length; j++)
			{
				if(op[i]>op[j])
				{
					aux=op[i];
					op[i]=op[j];
					op[j]=aux;
				}
			}
		}
		for (int i=0; i < op.length; i++)
		{
			System.out.println(op[i]);
		}
	}
	
	//Ejercicio 13
	
	public static void arrayDoble(Scanner input)
	{
		int[] num1 = new int [5];
		int[] num2 = new int [5];
		int[] num3 = new int [num1.length+num2.length];
		int n=1;
		int x;
		for (int i=0; i < num3.length; i++)
		{
			System.out.println(n+++". Dime un numero");
			x = input.nextInt();
			
			if (i>num1.length-1)
			{
				num2[i-num1.length]=x;
			}
			else
			{
				num1[i]=x;
			}
		}
		for (int i=0; i < num3.length; i++)
		{
			if(i<5)
			{
				num3[i]=num1[i];
			}
			else
			{
				num3[i]=num2[i-num1.length];
			}
			
		}
		for (int i=0; i < 10; i++)
		{
			System.out.println(num3[i]);
		}
	}
	
	//Ejercicio 14
	
	public static void arrayDuplicar(Scanner input)
	{
		int[] num1 = new int [5];
		int[] num2 = new int [num1.length];
		int n=1;
		int x;
		for (int i=0; i < num1.length; i++)
		{
			System.out.println(n+++". Dime un numero");
			x = input.nextInt();
			num1[i]=x;
			num2[i]=num1[i]*2;
		}
		for (int i=0; i < num2.length; i++)
		{
			System.out.println(num2[i]);
		}
	}
	
	//Ejercicio 15
	
	public static void arrayDupOrden(Scanner input)
	{
		int[] num1 = new int [5];
		int[] num2 = new int [num1.length];
		int[] num3 = new int [num1.length];
		int n=1;
		int x;
		int aux;
		for (int i=0; i < num1.length; i++)
		{
			System.out.println(n+++". Dime un numero");
			x = input.nextInt();
			num1[i]=x;
			num2[i]=num1[i]*2;
			num3[i]=num2[i];
		}
		for (int i=0; i < num3.length; i++)
		{
			for (int j= i+1; j < num3.length; j++)
			{
				if(num3[i]>num3[j])
				{
					aux=num3[i];
					num3[i]=num3[j];
					num3[j]=aux;
					
				}
			}
		}
		for (int i=0; i < num3.length; i++)
		{
			System.out.println(num3[i]);
		}
			
	}
		
	//Ejercicio 16
	
	public static void arrayParesSuma()
	{
		int[] num1 = new int [100];
		int x=1;
		int sum=0;
		System.out.println("Estos son los 100 primeros numeros pares");
		for (int i=0; i < num1.length; i++)
		{
			if(x%2==0)
			{
				if(num1[i-1]==0)
				{
					i--;
					num1[i]=x;
					System.out.println(num1[i]);
				}
				else
				{
					num1[i]=x;
					System.out.println(num1[i]);
				}
			}
			sum+=num1[i];
			x++;
		}
		System.out.println("Esta es la suma de todos los números: "+sum);
	}
	
	//Ejercicio 17
	
	public static void arrayMedia(Scanner input)
	{
		int[] num1 = new int [10];
		int x=1;
		int media=0;
		for (int i=0; i < num1.length; i++)
		{
			System.out.println(x+++". Dime un numero");
			num1[i]= input.nextInt();
			media+=num1[i];
		}
		System.out.println("La media de los 10 numeros es: "+media/num1.length);
	}
	
	//Ejercicio 18
	
	public static void arrayOrdenados2(Scanner input)
	{
		int[] num1 = new int [10];
		int x=1,aux=0;
		for (int i=0; i < num1.length; i++)
		{
			System.out.println(x+++". Dime un numero(negativos y positivos)");
			num1[i]= input.nextInt();
		}
		for (int i=1; i<num1.length; i++)
		{
			for (int j=1; j<num1.length-i; j++)
			{
				if (num1[j]>num1[j+1])
				{
					aux=num1[j];
					num1[j]= num1[j+1];
					num1[j+1]=aux;
				}
			}
		}
		for (int i=1; i<num1.length; i++)
		{
			System.out.println(num1[i]);
		}
	}

	//Ejercicio 19/20

	public static void arrayPositivos(Scanner input)
	{
		int[] num1 = new int [10];
		int x=1;
		int p=0,n=0,c=0;
		for (int i=0; i < num1.length; i++)
		{
			System.out.println(x+++". Dime un numero");
			num1[i]= input.nextInt();
			if (num1[i]>0)
			{
				p++;
			}
			else
			{
				if(num1[i]<0)
				{
					n++;
				}
				else
				{
					c++;
				}
			}
		}
		System.out.println("Hay "+p+" números positivos, "+n+" números negativos y "+c+" ceros");
	}
	
	//Ejercicio 21

	public String arrayBuscar(Scanner input)
	{
		int[] num1 = new int [20];
		int posi=0;
		int x=1;
		int b;
		String result="";
		for (int i=0; i < num1.length; i++)
		{
			System.out.println(x+++". Dime un numero");
			num1[i]= input.nextInt();
		}
		System.out.println("Qué número quieres buscar?");
		b=input.nextInt();
		for (int i=0; i < num1.length; i++)
		{
			if(num1[i]==b)
			{
				posi=i;
			}
			else
			{
				posi=-1;
			}
		}
		if (posi>=0)
		{
			result="El número pedido "+b+" se encuentra en la posición "+posi;
		}
		else
		{
			result="No existe el numero.";
		}
		
		return result;
	}
	
	//Ejercicio 22
	
	
	
	
	
}
