package Bombilla;

import java.util.Scanner;

public class Main 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String menu="1";
		while (menu!="6")
		{
		
		System.out.println("Hay 20 bombillas y tienes 6 opciones"
				+ "\n1. Activar el interruptor general."
				+ "\n2. Desactivar el interruptor general."
				+ "\n3. Encender una bombilla."
				+ "\n4. Apagar una bombilla."
				+ "\n5. Estado de las bombillas."
				+ "\n6. Fin.");
		menu = input.nextLine();
		switch (menu)
		{
		case "1":
			bombillas.encenderGeneral();
		break;
		case "2":
			bombillas.apagarGeneral();
		break;
		case "3":
			System.out.println(bombillas.encenderBombilla(input));
		break;
		case "4":
			bombillas.apagarBombilla(input);
		break;
		case "5":
			bombillas.estadoBombillas();
		break;
		default:
			System.out.println("Ese ejercicio no existe.");
		break;
		}
		}
		input.close();
	}

}
