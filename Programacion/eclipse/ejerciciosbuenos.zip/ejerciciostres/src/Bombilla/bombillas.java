package Bombilla;

import java.util.Scanner;

public class bombillas 
{
	private static boolean bombillas[] = new boolean [20];
	private static boolean intGeneral;
	private static boolean intBombilla;
	
	public static boolean[] isBooleanBombillas() 
	{
		return bombillas;
	}

	public static void setBombillas(boolean[] _bombillas) 
	{
		bombillas = _bombillas;
	}

	public static boolean isIntGeneral() 
	{
		return intGeneral;
	}

	public static void setIntGeneral(boolean _intGeneral) 
	{
		intGeneral = _intGeneral;
	}

	public static boolean isIntBombilla() 
	{
		return intBombilla;
	}

	public static void setIntBombilla(boolean _intBombilla) 
	{
		intBombilla = _intBombilla;
	}

	public static boolean encenderGeneral()
	{
		System.out.println("El interruptor general esta encendido");
		return !isIntGeneral();
	}
	
	public static boolean apagarGeneral()
	{
		System.out.println("El interruptor general esta apagado");
		return isIntGeneral();
	}
	
	public static String encenderBombilla(Scanner input)
	{
		String result="";
		int n;
		System.out.println("¿Bombilla que quieres encender?");
		n=input.nextInt();
		input.nextLine();
		for (int i=0; i < bombillas.length; i++)
		{
			if (n==i && !isIntGeneral())
			{
				bombillas[i]=isIntBombilla();
			}
			else
			{
				result="Todas las bombillas estan apagadas, el interruptor general esta apagado.";
			}
			
		}
		for (int i=0; i < bombillas.length; i++)
		{
			if(bombillas[i]=isIntBombilla())
			{
				result="La bombilla "+n+" está encendida.";
			}
			else
			{
				result="La bombilla "+n+" está apagada." ;
			}
		}
		return result;
	}
	
	public static boolean apagarBombilla(Scanner input)
	{
		boolean x;
		x=!isIntBombilla();
		return x;
	}
	
	public static void estadoBombillas()
	{
		for (int i=0; i < bombillas.length; i++)
		{
			
		}
	}
}
