package clasesEjemplos;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Punto p1 = new Punto();
		p1.setAbscisa(20);
		p1.setOrdenada(10);
		System.out.println(p1.toString());
		Rectangulo r1 = new Rectangulo();
		r1.setAbscisa1(1);
		r1.setOrdenada1(1);
		r1.setAbscisa2(5);
		r1.setOrdenada2(3);
		System.out.println(r1.toString());
		System.out.println(r1.desplazar(input));
		input.close();
	}

}
