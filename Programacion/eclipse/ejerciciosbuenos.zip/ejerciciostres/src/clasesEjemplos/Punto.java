package clasesEjemplos;

public class Punto 
{
	
	//Definición de atributos.
	private int abscisa; //Eje X
	private int ordenada; //Eje Y
	//Definición de métodos.
	
	public Punto()
	{
		abscisa = 0;
		ordenada = 0;
	}
	
	int getAbscisa()
	{
		return abscisa;
	}
	void setAbscisa(int x)
	{
		abscisa = x;
	}
	
	int getOrdenada()
	{
		return ordenada;
	}
	void setOrdenada(int x)
	{
		ordenada = x;
	}
	public String toString()
	{
		String info="Eje x "+getAbscisa()+"\nEje y "+getOrdenada();
		return info;
	}
}
