package clasesEjemplos;

import java.util.Scanner;

class Rectangulo 
{
	private double abscisa1; //Eje X1
	private double ordenada1; //Eje Y1
	private double abscisa2; //Eje X2
	private double ordenada2; //Eje Y2
	private static int numRectangulo;
	private static String nombre;
	public final String nombreFigura="Rectangulo";
	public final double PI=3.1416;
	
	
	double getAbscisa1() {
		return abscisa1;
	}
	void setAbscisa1(double x1) {
		abscisa1 = x1;
	}
	double getOrdenada1() {
		return ordenada1;
	}
	void setOrdenada1(double y1) {
		ordenada1 = y1;
	}
	double getAbscisa2() {
		return abscisa2;
	}
	void setAbscisa2(double x2) {
		abscisa2 = x2;
	}
	double getOrdenada2() {
		return ordenada2;
	}
	void setOrdenada2(double y2) {
		ordenada2 = y2;
	}
	
	public int getNumRectangulo() {
		return numRectangulo;
	}
	public void setNumRectangulo(int numRectangulo) {
		this.numRectangulo = numRectangulo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String _nombre) {
		nombre = _nombre;
	}
	public String getNombreFigura() {
		return nombreFigura;
	}
	public double getPI() {
		return PI;
	}
	public double base()
	{
		double base1;
		base1=getAbscisa2()-getAbscisa1();
		return base1;
	}
	
	public double altura()
	{
		double altura;
		altura=getOrdenada2()-getOrdenada2();
		return altura;
	}
	
	public double calcularSuperficie()
	{
		
		double resultado=base()*altura();
		return resultado;
	}
	
	public double calcularPerimetro()
	{
		double resultado=base()+altura()*2;
		return resultado;
	}
	
	public String desplazar(Scanner input)
	{
		String result;
		double x;
		double y;
		System.out.println("Cuantos puntos quieres mover de x?");
		x=input.nextInt();
		System.out.println("Cuantos puntos quieres mover de y?");
		y=input.nextInt();
		abscisa1+=x;
		abscisa2+=x;
		ordenada1+=y;
		ordenada2+=y;
		result="Eje x1= "+getAbscisa1()+" Eje y1= "+getOrdenada1()+
				"\nEje x2= "+getAbscisa2()+" Eje y2= "+getOrdenada2();
		return result;
	}
	
	public String toString()
	{
		String info="Figura: "+getNombreFigura()+"\nEje x1 "+getAbscisa1()+
				"\nEje y1 "+getOrdenada1()+"\nEje x2 "+getAbscisa2()+"\nEje y2 "+getOrdenada2()+
				"\nEl area es de "+calcularSuperficie()+"\nEl perímetro es "+calcularPerimetro();
		return info;
	}
}
