package ejerciciosBateria1;

import java.util.Scanner;

//import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		EjerciciosPSEINT ej1 = new EjerciciosPSEINT();
		System.out.println("Bateria");
		String tipo = input.nextLine();
		switch (tipo)
		{
			case "1":
				ej1.MostrarEjer1(input);
			break;
			case "2":
				ej1.MostrarEjer2(input);
			break;
			case "3":
				ej1.MostrarEjer3(input);
			break;
			case "4":
				ej1.MostrarEjer4(input);
			break;
			case "5":
				ej1.MostrarEjer5(input);
			break;
			case "6":
				ej1.MostrarEjer6(input);
			break;
			case "7":
				ej1.MostrarEjer7(input);
			break;
			case "8":
				ej1.MostrarEjer8(input);
			break;
			case "9":
				ej1.MostrarEjer9(input);
			break;
			case "10":
				ej1.MostrarEjer10(input);
			break;
			case "11":
				ej1.MostrarEjer11(input);
			break;
			case "12":
				ej1.MostrarEjer12(input);
			break;
			case "13":
				ej1.MostrarEjer13(input);
			break;
			case "14":
				ej1.MostrarEjer14(input);
			break;
			case "15":
				ej1.MostrarEjer15(input);
			break;
			case "16":
				ej1.MostrarEjer16(input);
			break;
			case "17":
				ej1.MostrarEjer17(input);
			break;
			case "18":
				ej1.MostrarEjer18(input);
			break;
			case "19":
				ej1.MostrarEjer19(input);
			break;
			case "20":
				ej1.MostrarEjer20(input);
			break;
			case "21":
				ej1.MostrarEjer21(input);
			break;
			case "22":
				ej1.MostrarEjer22(input);
			break;
			case "23":
				ej1.MostrarEjer23(input);
			break;
			case "24":
				ej1.MostrarEjer24(input);
			break;
			case "25":
				ej1.MostrarEjer25(input);
			break;
			case "26":
				ej1.MostrarEjer26(input);
			break;
			case "27":
				ej1.MostrarEjer27(input);
			break;
			case "28":
				ej1.MostrarEjer28(input);
			break;
			case "29":
				ej1.MostrarEjer29(input);
			break;
			case "30":
				ej1.MostrarEjer30(input);
			break;
			case "31":
				ej1.MostrarEjer31(input);
			break;
			case "32":
				ej1.MostrarEjer32(input);
			break;
		}
			input.close();
	}
}
	
	