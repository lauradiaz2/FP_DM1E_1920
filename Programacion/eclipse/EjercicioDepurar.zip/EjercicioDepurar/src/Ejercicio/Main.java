package Ejercicio;

public class Main 
{
	public static void main(String[] args) 
	{
		persona p1 = new persona();
		p1.mostrarInfo();
	}
}
