package calculadora;

public class Operaciones 
{
	private static String suma;
	private static String resta;
	private static String mult;
	private static String div;
	
	public String getSuma() 
	{
		return suma;
	}
	public void setSuma(String suma) 
	{
		this.suma = suma;
	}
	public String getResta() 
	{
		return resta;
	}
	public void setResta(String resta) 
	{
		this.resta = resta;
	}
	public String getMult() 
	{
		return mult;
	}
	public void setMult(String mult) 
	{
		this.mult = mult;
	}
	public String getDiv() 
	{
		return div;
	}
	public void setDiv(String div) 
	{
		this.div = div;
	}
	
	public String opSuma(String operacion1)
	{
		String num1="", num2="",aux="",result="";
		int x=0,n1=0,n2=0;
		for(int i =0; i<operacion1.length();i++)
		{
			char operacion =operacion1.charAt(i);
			if(operacion=='+')
			{
				x++;
			}
			else
			{
				if(x==1)
				{
					num2+= String.valueOf(operacion);
				}
				else
				{
					num1+=String.valueOf(operacion);
				}
			}
		}
		n1=Integer.parseInt(num1);
		n2=Integer.parseInt(num2);
		n1+=n2;
		result =String.valueOf(n1);
		setSuma(result);
		return getSuma();
	}
	
	public String opResta(String operacion1)
	{
		String num1="", num2="",result="";
		int x=0,n1=0,n2=0;
		for(int i =0; i<operacion1.length();i++)
		{
			char operacion =operacion1.charAt(i);
			if(operacion=='-')
			{
				x++;
			}
			else
			{
				if(x==1)
				{
					num2+= String.valueOf(operacion);
				}
				else
				{
					num1+=String.valueOf(operacion);
				}
			}
		}
		n1=Integer.parseInt(num1);
		n2=Integer.parseInt(num2);
		n1-=n2;
		result =String.valueOf(n1);
		setSuma(result);
		return getSuma();
	}
	
	public String opMultiplicar(String operacion1)
	{
		String num1="", num2="",result="";
		int x=0,n1=0,n2=0;
		for(int i =0; i<operacion1.length();i++)
		{
			char operacion =operacion1.charAt(i);
			if(operacion=='*')
			{
				x++;
			}
			else
			{
				if(x==1)
				{
					num2+= String.valueOf(operacion);
				}
				else
				{
					num1+=String.valueOf(operacion);
				}
			}
		}
		n1=Integer.parseInt(num1);
		n2=Integer.parseInt(num2);
		n1*=n2;
		result =String.valueOf(n1);
		setSuma(result);
		return getSuma();
	}
	
	public String opDivision(String operacion1)
	{
		String num1="", num2="",result="";
		int x=0,n1=0,n2=0;
		for(int i =0; i<operacion1.length();i++)
		{
			char operacion =operacion1.charAt(i);
			if(operacion=='/')
			{
				x++;
			}
			else
			{
				if(x==1)
				{
					num2+= String.valueOf(operacion);
				}
				else
				{
					num1+=String.valueOf(operacion);
				}
			}
		}
		n1=Integer.parseInt(num1);
		n2=Integer.parseInt(num2);
		n1/=n2;
		result =String.valueOf(n1);
		setSuma(result);
		return getSuma();
	}
}
