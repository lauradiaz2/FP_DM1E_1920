package calculadora;

import java.util.Scanner;

public class MainCalculadora 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Operaciones oper = new Operaciones();
		System.out.println("CALCULADORA: ");
		System.out.print("Operación: ");
		String operacion1,operacion2="";
		operacion1=input.nextLine();
		while(!operacion2.contentEquals("FIN"))
		{
			switch (separar(operacion1))
			{
			case "+":
				System.out.println(oper.opSuma(operacion1));
				System.out.println("Si no quieres operar mas escribe: FIN");
				operacion2=input.nextLine();
				operacion1=oper.opSuma(operacion1)+operacion2;
			break;
			case "-":
				System.out.println(oper.opResta(operacion1));
				System.out.println("Si no quieres operar mas escribe: FIN");
				operacion2=input.nextLine();
				operacion1=oper.opResta(operacion1)+operacion2;
			break;
			case "/":
				System.out.println(oper.opDivision(operacion1));
				System.out.println("Si no quieres operar mas escribe: FIN");
				operacion2=input.nextLine();
				operacion1=oper.opDivision(operacion1)+operacion2;
			break;
			case "*":
				System.out.println(oper.opMultiplicar(operacion1));
				System.out.println("Si no quieres operar mas escribe: FIN");
				operacion2=input.nextLine();
				operacion1=oper.opMultiplicar(operacion1)+operacion2;
			break;
			default:
				System.out.println("Esa operación no se puede realizar.");
			break;
			}
		}
		
		
		
		input.close();
	}

	public static String separar(String operacion1)
	{
		String aux="";
		for(int i =0; i<operacion1.length();i++)
		{
			char operacion =operacion1.charAt(i);
			if(operacion=='+' || operacion=='-' || operacion=='/' || operacion=='*' )
			{
				aux=String.valueOf(operacion);
			}
		}
		return aux;
	}
}
